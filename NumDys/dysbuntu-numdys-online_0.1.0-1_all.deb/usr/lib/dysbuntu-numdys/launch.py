#!/usr/bin/python3
"""Installe à la première utilisation les sources officielles Dysbuntu, sans sudo.

L'installation du paquet .deb est immédiate et possible sans réseau.
La première utilisation nécessite GitHub et récupère le commit exact indiqué.
Ensuite, tout fonctionne sans connexion (sauf dépendances facultatives).
"""
import fcntl
import os
from pathlib import Path
import shutil
import subprocess
import sys

REVISION = "011886cb3a33769322cafe01d2dea1024d9061ca"
REMOTE = "https://github.com/wensingmathis/Dysbuntu.git"
APPS = {
    "numdys": ("NumDys/main.py", "logo Dysbuntu.png"),
    "vocalis": ("Vocalis/main.py", "Vocalis/Vocalis.jpeg"),
}

def notice(message):
    print(message, file=sys.stderr)
    if shutil.which("zenity"):
        subprocess.run(["zenity", "--error", "--title", "Dysbuntu",
                        "--width", "460", "--text", message], check=False)
    elif shutil.which("notify-send"):
        subprocess.run(["notify-send", "-u", "critical",
                        "Dysbuntu", message], check=False)
    else:
        try:
            from tkinter import Tk, messagebox
            root = Tk()
            root.withdraw()
            messagebox.showerror("Dysbuntu", message)
            root.destroy()
        except Exception:
            pass

def git(args):
    return subprocess.run(["git", *args], check=True,
                          env={**os.environ, "GIT_TERMINAL_PROMPT": "0"},
                          stdout=subprocess.DEVNULL, stderr=subprocess.PIPE,
                          text=True)

def valid_checkout(path):
    if not path.is_dir():
        return False
    try:
        proc = subprocess.run(["git", "-C", str(path), "rev-parse", "HEAD"],
                              capture_output=True, text=True, check=True)
        return proc.stdout.strip() == REVISION
    except (OSError, subprocess.CalledProcessError):
        return False

def install_shortcut(app, icon_path):
    # Ne modifie pas le logo et ne remplace aucun fichier image.
    desktop = Path.home() / ".local/share/applications" / f"{app}.desktop"
    desktop.parent.mkdir(parents=True, exist_ok=True)
    titles = {"numdys": "NumDys", "vocalis": "Vocalis"}
    desktop.write_text(
        "[Desktop Entry]\nType=Application\n"
        f"Name={titles[app]}\nExec=/usr/bin/{app}\n"
        f"Icon={icon_path}\nTerminal=false\n"
        "Categories=Education;Utility;\n",
        encoding="utf-8"
    )

def run():
    app = Path(sys.argv[0]).name.lower()
    if app not in APPS:
        notice("Application Dysbuntu inconnue.")
        return 1

    data_home = Path(os.environ.get("XDG_DATA_HOME",
                                   str(Path.home() / ".local/share")))
    home = data_home / "dysbuntu-source"
    home.mkdir(parents=True, exist_ok=True)
    source = home / REVISION
    with (home / ".installation.lock").open("w") as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
        if not valid_checkout(source):
            if source.exists():
                notice("Dossier Dysbuntu incorrect : " + str(source)
                       + "\nSupprimez-le pour réinstaller les sources.")
                return 1
            temp = home / (f".tmp-{os.getpid()}")
            try:
                git(["init", "-q", str(temp)])
                git(["-C", str(temp), "remote", "add", "origin", REMOTE])
                git(["-C", str(temp), "fetch", "-q", "--depth=1",
                     "origin", REVISION])
                git(["-C", str(temp), "checkout", "-q", "--detach",
                     "FETCH_HEAD"])
                if not valid_checkout(temp):
                    raise RuntimeError("Version téléchargée incorrecte.")
                temp.rename(source)
            except (OSError, subprocess.CalledProcessError, RuntimeError) as exc:
                shutil.rmtree(temp, ignore_errors=True)
                detail = getattr(exc, "stderr", None) or str(exc)
                notice("Impossible de télécharger le code officiel Dysbuntu.\n"
                       "Une connexion Internet est nécessaire au premier lancement.\n\n"
                       + detail[-600:])
                return 1

        main_path, image = APPS[app]
        image_path = source / image
        script = source / main_path
        if not (script.is_file() and image_path.is_file()):
            notice("Sources Dysbuntu incomplètes. Réinstallation nécessaire.")
            return 1
        install_shortcut(app, image_path)
    try:
        os.execv("/usr/bin/python3",
                 ["/usr/bin/python3", str(script), *sys.argv[1:]])
    except OSError as exc:
        notice(f"Impossible de lancer {app} : {exc}")
        return 1

if __name__ == "__main__":
    sys.exit(run())
